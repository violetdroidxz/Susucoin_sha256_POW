Susucoin Core version 0.16.99.1 is now available from:

  <https://susukino.com>

This is a new release, including new features, bugfixes and performance 
improvements.

Please report bugs using the issue tracker at GitHub:

  <https://github.com/susucoin/susucoin/issues>

How to Upgrade
==============

If you are running an older version, shut it down. Wait until it has completely
shut down (which might take a few minutes for older versions), then run the
installer (on Windows) or just copy over `/Applications/Susucoin-Qt` (on Mac)
or `susucoind`/`susucoin-qt` (on Linux).

Compatibility
==============

Susucoin Core is extensively tested on multiple operating systems using
the Linux kernel, macOS 10.8+, and Windows 7 and newer (Windows XP is not supported).

Susucoin Core should also work on most other Unix-like systems but is not
frequently tested on them.

Notable changes
===============

Bug Fixes
---------

A reindexing issue was fixed caused by the genesis block being a version 1 block.

Denial-of-Service vulnerability
-------------------------------

A denial-of-service vulnerability exploitable by miners has been discovered in
Bitcoin Core versions 0.14.0 up to 0.16.99. It is recommended to upgrade any of
the vulnerable versions as soon as possible. 

Low-level data storage changes
------------------------------

- Maximum size of data in data carrier transactions has been increased from
  `83` to `516`.

- Maximum amount of `OP_RETURN` transactions in a txout has been increased 
  from `1` to `16`.

Low-level RPC changes
---------------------

- Susucoin now relays data by default. Can be disabled using the 
  `-datacarrier` flag.

Credits
=======

Thanks to everyone who directly contributed to this release:
  - sd8
  - Ron Watkins
  - Stevenson Holasca


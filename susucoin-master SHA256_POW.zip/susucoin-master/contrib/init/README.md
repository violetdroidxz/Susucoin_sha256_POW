Sample configuration files for:
```
SystemD: susucoind.service
Upstart: susucoind.conf
OpenRC:  susucoind.openrc
         susucoind.openrcconf
CentOS:  susucoind.init
macOS:    org.susucoin.susucoind.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
